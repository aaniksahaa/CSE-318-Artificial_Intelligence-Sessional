package util;

public class Constants {
    public static final double FRACTION_THRESHOLD = 1e-10;
}
